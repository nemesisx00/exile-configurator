# Exile Configurator #

Exile Configurator is an application for easily maintaining a set of custom item definitions for inclusion in the vendor lists of Exile Mod for ArmA 3.